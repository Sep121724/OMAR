-- SQL Dump: interacteach_db
CREATE DATABASE IF NOT EXISTS interacteach_db;
USE interacteach_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  role ENUM('student','teacher','admin') DEFAULT 'student',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  status ENUM('present','absent','late') DEFAULT 'present',
  timestamp DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS quizzes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  content TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS analytics_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  event VARCHAR(255),
  details TEXT,
  event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO users (name, email, password, role) VALUES 
('Juan Dela Cruz','juan@example.com','$2y$10$abcdefghijklmnopqrstuvwxyzABCDEFG', 'student'),
('Maria Santos','maria@example.com','$2y$10$abcdefghijklmnopqrstuvwxyzABCDEFG', 'teacher');