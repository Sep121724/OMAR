import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(InteracTeachApp());

class InteracTeachApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'InteracTeach+',
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      final response = await http.post(
        Uri.parse('https://YOUR_SERVER_DOMAIN/api/login.php'),
        body: {
          'email': emailController.text.trim(),
          'password': passwordController.text.trim(),
        },
      );
      final data = json.decode(response.body);
      if (data['success'] == true) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage(user: data['user'])));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'] ?? 'Login failed')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Network error')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('InteracTeach+ Login')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: InputDecoration(labelText: 'Email')),
            TextField(controller: passwordController, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(onPressed: login, child: loading ? CircularProgressIndicator(color: Colors.white) : Text('Login')),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final Map user;
  HomePage({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('InteracTeach+')),
      body: Center(child: Text('Welcome, ${user['name']}')),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.check),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SubmitAttendancePage(userId: user['id']))),
      ),
    );
  }
}

class SubmitAttendancePage extends StatefulWidget {
  final int userId;
  SubmitAttendancePage({required this.userId});

  @override
  _SubmitAttendancePageState createState() => _SubmitAttendancePageState();
}

class _SubmitAttendancePageState extends State<SubmitAttendancePage> {
  bool sending = false;

  Future<void> submitAttendance(String status) async {
    setState(() => sending = true);
    try {
      final response = await http.post(Uri.parse('https://YOUR_SERVER_DOMAIN/api/attendance.php'),
        body: {'user_id': widget.userId.toString(), 'status': status});
      final data = json.decode(response.body);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'] ?? 'No response')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Network error')));
    } finally {
      setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Submit Attendance')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(child: sending ? CircularProgressIndicator() : Text('Present'), onPressed: () => submitAttendance('present')),
            SizedBox(height: 10),
            ElevatedButton(child: sending ? CircularProgressIndicator() : Text('Absent'), onPressed: () => submitAttendance('absent')),
          ],
        ),
      ),
    );
  }
}