<?php
header('Content-Type: application/json');
require 'db.php';

$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;

if (!$email || !$password) {
    echo json_encode(['success'=>false, 'message'=>'Missing parameters']);
    exit;
}

$stmt = $conn->prepare("SELECT id,name,email,password,role FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    echo json_encode(['success'=>false, 'message'=>'User not found']);
    exit;
}
$user = $res->fetch_assoc();
if (password_verify($password, $user['password'])) {
    unset($user['password']);
    echo json_encode(['success'=>true, 'user'=>$user]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Invalid credentials']);
}
?>