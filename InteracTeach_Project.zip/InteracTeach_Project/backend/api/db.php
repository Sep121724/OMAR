<?php
// db.php - Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "interacteach_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success'=>false, 'message'=>'DB connection failed: '.$conn->connect_error]));
}
$conn->set_charset('utf8mb4');
?>