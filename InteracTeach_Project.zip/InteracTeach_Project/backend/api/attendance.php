<?php
header('Content-Type: application/json');
require 'db.php';

$user_id = $_POST['user_id'] ?? null;
$status = $_POST['status'] ?? null;

if (!$user_id || !$status) {
    echo json_encode(['success'=>false, 'message'=>'Missing parameters']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO attendance (user_id, status, timestamp) VALUES (?, ?, NOW())");
$stmt->bind_param("is", $user_id, $status);
if ($stmt->execute()) {
    echo json_encode(['success'=>true, 'message'=>'Attendance submitted']);
} else {
    echo json_encode(['success'=>false, 'message'=>'DB insert failed: '.$conn->error]);
}
?>