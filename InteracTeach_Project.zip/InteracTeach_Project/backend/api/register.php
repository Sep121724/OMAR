<?php
header('Content-Type: application/json');
require 'db.php';

$name = $_POST['name'] ?? null;
$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;
$role = $_POST['role'] ?? 'student';

if (!$name || !$email || !$password) {
    echo json_encode(['success'=>false, 'message'=>'Missing parameters']);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
$stmt->bind_param("ssss", $name, $email, $hash, $role);
if ($stmt->execute()) {
    echo json_encode(['success'=>true, 'message'=>'Registered successfully']);
} else {
    echo json_encode(['success'=>false, 'message'=>'Register failed: '.$conn->error]);
}
?>