<?php
header('Content-Type: application/json');
require 'db.php';

$from = $_GET['from'] ?? null;
$to = $_GET['to'] ?? null;

// Example: return count of attendance by status
$sql = "SELECT status, COUNT(*) as cnt FROM attendance";
if ($from && $to) {
    $sql .= " WHERE timestamp BETWEEN ? AND ? GROUP BY status";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $from, $to);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $sql .= " GROUP BY status";
    $res = $conn->query($sql);
}

$data = [];
while ($row = $res->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode(['success'=>true,'data'=>$data]);
?>