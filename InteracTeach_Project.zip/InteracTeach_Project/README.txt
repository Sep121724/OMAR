
InteracTeach+ Minimal Project
============================

Contents:
- flutter_app/ (only lib/main.dart and pubspec.yaml provided)
- backend/api/ (PHP files: db.php, register.php, login.php, attendance.php, analytics.php)
- sql/interacteach_db.sql

Setup (Backend):
1. Place backend/api files on a PHP-enabled server (e.g., XAMPP, LAMP).
2. Import sql/interacteach_db.sql into MySQL (via phpMyAdmin or mysql CLI).
3. Update db.php credentials if needed.
4. Ensure the server is accessible via HTTPS (recommended) and note the base URL (e.g., https://your-server.com/api/).

Setup (Flutter):
1. Create a new Flutter project (flutter create interacteach_app).
2. Replace lib/main.dart with provided main.dart.
3. Update pubspec.yaml dependencies and run flutter pub get.
4. Replace 'YOUR_SERVER_DOMAIN' in main.dart with your API server domain.
5. Run on emulator or device.

Security notes:
- Use HTTPS for API calls.
- Never store plain passwords. Use password_hash (PHP) and HTTPS during transmission.
- Consider adding JWT or session-based authentication for production.
